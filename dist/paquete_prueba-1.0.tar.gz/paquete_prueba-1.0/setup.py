from setuptools import setup

setup(
    name="paquete_prueba",
    version= "1.0",
    description= "paquete de prueba",
    author= "yo",

    packages=["paquete"]
)